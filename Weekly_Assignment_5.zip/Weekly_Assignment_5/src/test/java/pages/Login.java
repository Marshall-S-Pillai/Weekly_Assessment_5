package pages;

import java.time.Duration;
import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.CommonMethods;

public class Login extends CommonMethods {
    WebDriverWait wait;
    WebDriver dr;
    Logger log = Logger.getLogger(Login.class);

    @FindBy(linkText = "Log in")
    WebElement loginLink;

    @FindBy(id = "Email")
    WebElement emailField;

    @FindBy(id = "Password")
    WebElement passwordField;

    @FindBy(id = "RememberMe")
    WebElement rememberMeCheckbox;

    @FindBy(xpath = "//button[text()='Log in']")
    WebElement loginButton;

    @FindBy(xpath = "//a[@class='ico-account']")
    WebElement accountLink;

    @FindBy(linkText = "Log out")
    WebElement logoutLink;

    @FindBy(xpath = "//div[@class='message-error']")
    WebElement errorMessage; 

    public Login(WebDriver dr) {
        this.dr = dr;
        PageFactory.initElements(dr, this);
        wait = new WebDriverWait(dr, Duration.ofSeconds(10));
    }

    public boolean loginUser(String user, String pwd, String expectedText) {
        log.info("Attempting login for user: " + user);
        loginLink.click();
        emailField.clear();
        emailField.sendKeys(user);
        passwordField.clear();
        passwordField.sendKeys(pwd);
        rememberMeCheckbox.click();
        loginButton.click();
        return verify(expectedText);
    }

    public boolean verify(String expectedText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(accountLink));
            String actualText = accountLink.getText();
            log.info("Verifying login. Expected: " + expectedText + ", Actual: " + actualText);
            return actualText.equals(expectedText);
        } catch (Exception e) {
            log.warn("Account link not found, login might have failed.");
            return false;
        }
    }

    public String getErrorMessage() {
        try {
            wait.until(ExpectedConditions.visibilityOf(errorMessage));
            String msg = errorMessage.getText();
            log.info("Error message captured: " + msg);
            return msg;
        } catch (Exception e) {
            log.warn("Error message not found.");
            return "";
        }
    }

    public void logout() {
        log.info("Logging out...");
        try {
            wait.until(ExpectedConditions.visibilityOf(logoutLink));
            wait.until(ExpectedConditions.elementToBeClickable(logoutLink));
            logoutLink.click();
            log.info("Logout successful.");
        } catch (Exception e) {
            log.warn("Normal click failed, using JavaScript click for logout.");
            JavascriptExecutor js = (JavascriptExecutor) dr;
            js.executeScript("arguments[0].click();", logoutLink);
        }
    }
}