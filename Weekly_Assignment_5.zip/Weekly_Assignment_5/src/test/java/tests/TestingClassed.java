package tests;

import java.time.Duration;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

import pages.Login;
import utilities.CommonMethods;

public class TestingClassed extends CommonMethods {

    Login login;
    WebDriverWait wait;

    @BeforeClass
    public void setUp() {
     //   launch_chrome();
        launch_edge();
        login = new Login(dr);
        wait = new WebDriverWait(dr, Duration.ofSeconds(10));
    }

    @BeforeMethod
    public void captureBeforeMethod() {
        takeScreenshot("BeforeMethod");
        System.out.println("Screenshot captured: BeforeMethod");
    }

    @Test(priority = 1)
    public void login_valid_credentials() {
        String user = "iammarshallhere@gmail.com";
        String pass = "Mars@9087";
        String expectedText = "My account";

        boolean isLoggedIn = login.loginUser(user, pass, expectedText);
        Assert.assertTrue(isLoggedIn, "Login failed or account text mismatch");
        System.out.println("Login successful");
    }

    @Test(priority = 2)
    public void verify_login() {
        String expectedText = "My account";
        boolean ok = login.verify(expectedText);
        Assert.assertTrue(ok, "Login failed or account text mismatch");
        System.out.println("Login verified");
    }

    @Test(priority = 3)
    public void logout() {
        login.logout();
        System.out.println("Logged out successfully");
    }

    @Test(priority = 4)
    public void login_invalid_credentials() {
        String user = "invaliduser@gmail.com";
        String pass = "WrongPass123";

        login.loginUser(user, pass, "My account");
        String actualError = login.getErrorMessage();
        Assert.assertTrue(actualError.contains("Login was unsuccessful"), "Error message mismatch");
        System.out.println("Invalid login error verified");
    }

    @AfterMethod
    public void captureAfterMethod(ITestResult result) {
        String status = result.getStatus() == ITestResult.SUCCESS ? "PASS" :
                        result.getStatus() == ITestResult.FAILURE ? "FAIL" : "SKIP";
        takeScreenshot("AfterMethod_" + result.getMethod().getMethodName() + "_" + status);
        System.out.println("Screenshot captured: AfterMethod_" + result.getMethod().getMethodName() + "_" + status);
    }

    @AfterClass
    public void tearDown() {
        closeBrowser();
        System.out.println("Browser closed");
    }
}