package tests;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.Login;
import utilities.CommonMethods;
import utilities.configreader;

public class TestingClass extends CommonMethods {

    configreader config = new configreader();
    Logger log = Logger.getLogger(TestingClass.class);
   
    Login login;
  
    @BeforeClass
    @Parameters("BROWSER")
    public void setUp(String browser) { //1st in sequence
        PropertyConfigurator.configure("src\\test\\resources\\log4j.properties");
        System.out.println("Launching browser: " + browser);
        launchBrowser(browser);
        login = new Login(dr);
    }
    @Test(priority = 1) 
    public void login() { //2nd in sequence
        String user = "iammarshallhere@gmail.com";
        String pass = "Mars@9087";
        String expectedText = "My account";
        boolean isLoggedIn = login.loginUser(user, pass, expectedText);
        System.out.println("Login Successfull");
        Assert.assertTrue(isLoggedIn, "Login failed or account text mismatch");
        log.info("Login successful");
    }

    @Test(priority = 2) //3rd in sequence
    public void verify_login() {
        String expectedText = "My account";
        boolean ok = login.verify(expectedText);
        System.out.println("Verified login text: " + expectedText);
        Assert.assertTrue(ok, "Login failed or account text mismatch");
        log.info("Login verified");
    }

    @Test(priority = 3) //4th in sequence
    public void logout() {
        login.logout();
        log.info("Logged out");
    }

    @AfterClass
    public void tearDown() {//5th in sequence
        closeBrowser();
        log.info("Browser closed");
    }
}

