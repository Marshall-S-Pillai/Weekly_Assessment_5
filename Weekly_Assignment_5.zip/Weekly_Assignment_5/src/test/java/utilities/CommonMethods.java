package utilities;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonMethods {
  public static  WebDriver dr;
   public static  WebDriverWait wait;

    public void launch_chrome() {
        
            System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
            dr = new ChromeDriver();
            dr.get("https://demo.nopcommerce.com/"); 

            dr.manage().window().maximize();
        
    }

    public void takeScreenshot(String fileName) {
        TakesScreenshot ts = (TakesScreenshot) dr;
        File src = ts.getScreenshotAs(OutputType.FILE);
        File dest = new File("Screenshot\\" + fileName + ".png");

        try {
            FileUtils.copyFile(src, dest);
            System.out.println("Screenshot saved: " + dest.getAbsolutePath());
        } catch (IOException e) {
            System.out.println("Failed to save screenshot: " + e.getMessage());
        }
    }

    public void closeBrowser() {
            dr.quit();
            System.out.println("Browser closed");
        }
    }
