package utilities;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonMethods {
    protected WebDriver dr;
    protected WebDriverWait wait;
    configreader config = new configreader();
    String url = config.getProperty("url");
    public void launchBrowser(String browser) {
        if (browser.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
            dr = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            System.setProperty("webdriver.edge.driver", "edgedriver_v141.exe");
            dr = new EdgeDriver();
        }
        dr.get(url);
        dr.manage().window().maximize();
        wait = new WebDriverWait(dr, Duration.ofSeconds(10));
    }

    public void closeBrowser() {
        if (dr != null) {
            dr.quit();
        }
    }
}